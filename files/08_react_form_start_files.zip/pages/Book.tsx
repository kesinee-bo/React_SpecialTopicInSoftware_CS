
import Book from "../types/Book";
import { books } from "../data/BookMockUp";
import BookDetail from "../components/book/BookDetail";


function BookPage() {
    return (

      <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">รายการหนังสือ</h1>
      <div className="flex flex-wrap justify-center items-start">
        {/* TODO: 3) อ่านข้อมูลใน books เพื่อนำข้อมูลหนังสือแต่ละเล่มมาแสดงใน BookDetail ผ่านคำสั่ง map */}
        {books.map((book: Book) => (
          <BookDetail key={book.id} book={book}  />
        ))}
      </div>
    </div>

    )
  }
  
  export default BookPage