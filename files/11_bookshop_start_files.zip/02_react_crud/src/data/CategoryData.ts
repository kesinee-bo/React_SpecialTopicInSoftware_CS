const categories =  ["Web Development"
                ,"Internet"
                ,"Java"
                ,"Microsoft .NET"
                ,"Mobile Technology"
                ,"Programming"
                ,"Software Engineering"
                ,"Data Science"
                ,"Machine Learning and AI"
                ,"อื่น ๆ"];

export { categories };






