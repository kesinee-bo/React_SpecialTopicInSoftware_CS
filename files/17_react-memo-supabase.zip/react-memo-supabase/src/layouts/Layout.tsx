import { ReactNode } from 'react';
import { useAuth } from '../services/useAuth';
import { Navigate } from 'react-router';
import Sidebar from './Sidebar';

type LayoutProps = {
  children: ReactNode;
  requireAuth?: boolean;
};

const Layout = ({ children, requireAuth = true }: LayoutProps) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (requireAuth && !user) {
    return <Navigate to="/sign-in" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {user && <Sidebar />}
      <div className={`${user ? 'lg:ml-64' : ''} min-h-screen`}>
        {/* {user && <Header />} */}
        <main className="p-4 sm:p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;